#include <stdio.h>
#include "types.h"


int kirbyGetDecmpSize(u8 *buffer) {
	u16 len;
	u8 cmd,ctrl;
	int i=0,size=0;

	while ((ctrl = buffer[i]) != 0xFF) {
		cmd = (ctrl >> 5);
		if (cmd == 0x07) { //extension
			cmd = ((ctrl >> 2) & 0x07);
			len = ((((ctrl & 0x03) << 8) | buffer[i+1]) + 1);
			i += 2;
		}
		else {
			len = ((ctrl & 0x1F) + 1);
			i++;
		}

		switch (cmd) {
			case 0x00: //uncompressed copy
				i += len;
				break;
			case 0x01: //RLE
			case 0x03: //RLE++
				i++;
				break;
			case 0x02: //2-byte RLE
				len <<= 1;
				//break; //No! Let it roll over!
			case 0x04: //LZ-copy
			case 0x05: //bit-reversing LZ-copy
			case 0x06: //LZ-reserve-copy
			case 0x07: //extended 0x07 ... should not happen, but would execute this
				i += 2;
				break;
		}
		size += len;
	}

	return size;
}

int kirbyDecmp(u8 *output, u8 *buffer) {
	u16 len,src;
	u8 ctrl,cmd,tmp,tmp2;
	int i=0,j=0;

	while ((ctrl = buffer[i]) != 0xFF) {
		cmd = (ctrl >> 5);
		if (cmd == 0x07) { //extension
			cmd = ((ctrl >> 2) & 0x07);
			len = ((((ctrl & 0x03) << 8) | buffer[i+1]) + 1);
			i += 2;
		}
		else {
			len = ((ctrl & 0x1F) + 1);
			i++;
		}

		switch (cmd) {
			case 0x00: //uncompressed copy
				while (len--) output[j++] = buffer[i++];
				break;
			case 0x01: //RLE
				while (len--) output[j++] = buffer[i];
				i++;
				break;
			case 0x02: //2-byte RLE
				while (len--) {
					output[j++] = buffer[i];
					output[j++] = buffer[i+1];
				}
				i += 2;
				break;
			case 0x03: //RLE++
				tmp = buffer[i++];
				while (len--) output[j++] = tmp++;
				break;
			case 0x04: //LZ-copy
			case 0x07: //extended 0x07 ... should not happen, but would execute this
				src = ((buffer[i] << 8) | buffer[i+1]);
				i += 2;
				while (len--) output[j++] = output[src++];
				break;
			case 0x05: //bit-reversing LZ-copy
				src = ((buffer[i] << 8) | buffer[i+1]);
				i += 2;
				while (len--) {
					tmp = output[src++];
					for (i = 0; i < 8; i++) {
						tmp2 = (tmp2 >> 1) | (tmp & 0x80);
						tmp <<= 1;
					}
					output[j++] = tmp2;
				}
				break;
			case 0x06: //LZ-reserve-copy
				src = ((buffer[i] << 8) | buffer[i+1]);
				i += 2;
				while (len--) output[j++] = output[src--];
				break;
		}
	}

	return (i+1);
}


void printUsage(char *filename) {
	int i;

	for (i = strlen(filename); i > 0; i--) if (filename[i] == '\\') break; //filter directories
	printf("Usage: %s <infile> <offset> <outfile>\n",filename+i);
	printf("    infile: \tInput ROM file.\n");
	printf("    offset: \tOffset of compressed data in ROM file. (Hex value)\n");
	printf("    outfile:\tOutput file.\n\n");
}

int main(int argc, char **argv) {
	FILE *fin,*fout;
	u32 offset;
	u8 *buffer,*output;
	int filesize,decmpsize,cmpsize;

	printf("UnKirby: Decompression utility for Kirby's Adventure & Kirby Super Star\nCopyright 2004 Parasyte\n\n");

	if (argc != 4) {
		printUsage(argv[0]);
		return 1;
	}

	//get command line args
	if (!(fin = fopen(argv[1],"rb"))) {
		printf("Unable to open input file!\n\n");
		return 1;
	}
	sscanf(argv[2],"%x",&offset);
	if (!(fout = fopen(argv[3],"wb"))) {
		printf("Unable to open output file!\n\n");
		fclose(fin);
		return 1;
	}

	//get filesize
	fseek(fin,0,SEEK_END);
	filesize = ftell(fin);
	fseek(fin,0,SEEK_SET);

	//load file into memory
	if (!(buffer = (u8*)malloc(filesize))) {
		printf("Unable to allocate %d bytes of memory!\n\n",filesize);
		fclose(fin);
		fclose(fout);
		return 1;
	}
	fread(buffer,1,filesize,fin);
	fclose(fin);


	//begin decompression!
	printf("Decompressing data from offset 0x%08X...\n",offset);

	//allocate memory for decompressed data
	decmpsize = kirbyGetDecmpSize(buffer+offset);
	if (!(output = (u8*)malloc(decmpsize))) {
		printf("Unable to allocate %d bytes of memory!\n\n",decmpsize);
		free(buffer);
		fclose(fout);
		return 1;
	}

	cmpsize = kirbyDecmp(output,buffer+offset);
	fwrite(output,1,decmpsize,fout);

	printf("Decompression completed successfully!\n\nCompressed data size:   0x%04X bytes\nDecompressed data size: 0x%04X bytes\n\n",cmpsize,decmpsize);

	free(buffer);
	free(output);
	fclose(fout);
	return 0;
}
