DST=../romhack.github.io
rm *.o *.~hs *.hi
rm -rf ${DST}/*
tar -zcvf ${DST}/src.tar.gz --exclude='site.exe' --exclude='files/*' --exclude='_site/*' *
cp -rf _site/* ${DST}/
