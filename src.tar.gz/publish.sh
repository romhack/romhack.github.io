#!/bin/bash
DST=../romhack.github.io
rm -rf ${DST}

git clone https://github.com/romhack/romhack.github.io.git ${DST}

rm *.o *.~hs *.hi
rm -rf _site/passgen/short/ _site/doc/short/ _site/news/
tar -zcvf ${DST}/src.tar.gz --exclude='site.exe' --exclude='files/*' --exclude='_site/*' --exclude='_cache/*' --exclude='.stack-work/*' *
cp -rf _site/* ${DST}/

cd ${DST}
git add .

echo 'Enter the commit message:'
read commitMessage

git commit -m "$commitMessage"

git push origin master
